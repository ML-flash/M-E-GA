"""
theory_sim6_gads_logged.py

Same mechanism as theory_sim6_gads.py (GADS-explicit Layer 6), but:
 - tracks two specific lineages across generations
 - emits a compact JSON event stream for the interactive player
 - small/short by default so it COMPLETES in a constrained environment

The JSON schema (one object):
{
  "meta": {pop, gens, seed, threshold, params...},
  "frames": [
     { "gen": int,
       "lineageA": [tokens], "lineageB": [tokens],
       "decodedA_len": int, "decodedB_len": int,
       "fitA": float, "fitB": float,
       "mg": { "<cid>": {"content":[tokens], "depth":int, "flatlen":int, "in_pr":bool, "in_db":bool, "db_age":int} , ... },
       "mg_size": int, "pr": [cids bottom->top], "db": {cid:age}, "reuse": int,
       "events": { "captures":[{cid,content}], "reuses":[{cid,into}], "rescues":[cid], "deletions":[cid], "opens":int },
       "stats": {"mean_fit":..,"mean_dlen":..,"dom_frac":..,"comp_frac":..}
     }, ...
  ]
}

Token legend for the player: 0='(' 1=')' 2='a' 3='b' ; >=4 = metagene cid
"""

import os, json, random, math, time
import matplotlib  # noqa (kept for parity; unused in logging build)

POPULATION_SIZE = int(os.environ.get("POP", "120"))
GENERATIONS     = int(os.environ.get("GENS", "120"))
SEED            = int(os.environ.get("SEED", "7"))
LOG_PATH        = os.environ.get("LOG", "run_log.json")
MAX_MG_EMIT     = int(os.environ.get("MAX_MG_EMIT", "60"))  # cap emitted MG entries for file size

MIN_LEN = 2
MAX_LEN = 40

ENABLE_CROSSOVER = False
NUM_PARENTS      = int(os.environ.get("PARENTS", "50"))

BOUNDARY_INSERT_PROB = 0.0035
BOUNDARY_REMOVE_PROB = 0.0020
CAPTURE_PROB = float(os.environ.get("CAP","0.09"))
MIN_CAPTURE_LEN = 2
MUTATION_PROB           = 0.05
DELIMITED_MUTATION_PROB = 0.02
OPEN_PROB = 0.005
SINGULARITY_THRESHOLD = 0.95
BASE_GENE_PROB = float(os.environ.get("BGP","0.57"))
MCO_DECAY = 0.90
PR_CAPACITY = int(os.environ.get("PR", "20"))
DB_THRESHOLD = 2
MAX_INLINE_LEN = 80000
ELITE_FRAC = 0.02
FITNESS_THRESHOLD = int(os.environ.get("FT", "120"))
OVER_PENALTY = 2
MAX_DECODE_DEPTH = 100

ENC_OPEN, ENC_CLOSE, ENC_BASE0, ENC_BASE1, FIRST_COMP_ID = 0, 1, 2, 3, 4


class MetaGenome:
    def __init__(self):
        self.store={}; self.reverse={}; self.next_id=FIRST_COMP_ID
        self.deps={}; self.rdeps={}; self.mco=[]; self.reuse_pool=[]
        self.pr=[]; self.db={}; self.backflow_failure=False
        self.uid_of={}      # cid -> stable uid (current incarnation)
        self.next_uid=1

    def decode(self, org):
        top=set(); result=[]
        for tok in org:
            if tok in (ENC_OPEN, ENC_CLOSE): continue
            elif tok >= FIRST_COMP_ID:
                top.add(tok); result.extend(self._expand(tok,0))
            else: result.append(tok)
        return result, top

    def _expand(self, cid, depth):
        if depth >= MAX_DECODE_DEPTH: return []
        if cid not in self.store: return []
        out=[]
        for tok in self.store[cid]:
            if tok in (ENC_OPEN, ENC_CLOSE): continue
            elif tok >= FIRST_COMP_ID: out.extend(self._expand(tok, depth+1))
            else: out.append(tok)
        return out

    def flatlen(self, cid, depth=0):
        if depth>=MAX_DECODE_DEPTH or cid not in self.store: return 0
        n=0
        for tok in self.store[cid]:
            if tok in (ENC_OPEN, ENC_CLOSE): continue
            elif tok>=FIRST_COMP_ID: n+=self.flatlen(tok, depth+1)
            else: n+=1
        return n

    def depth_of(self, cid, visiting=None):
        if cid not in self.store: return 0
        if visiting is None: visiting=set()
        if cid in visiting: return 0
        visiting.add(cid)
        d=self.deps.get(cid,set())
        return 0 if not d else 1+max(self.depth_of(x,visiting) for x in d)

    def pr_register(self, cid):
        if cid in self.pr:
            self.pr_refresh(cid); return
        if len(self.pr) >= PR_CAPACITY: self._pr_displace()
        self.pr.append(cid)

    def pr_refresh(self, cid):
        if cid in self.pr:
            self.pr.remove(cid); self.pr.append(cid)

    def _pr_displace(self):
        if not self.pr: return
        self.db[self.pr.pop(0)] = 0

    def db_rescue(self, cid):
        if cid in self.db:
            del self.db[cid]
            if len(self.pr) >= PR_CAPACITY: self._pr_displace()
            self.pr.append(cid)
            return True
        return False

    def db_tick(self, inline_log=None):
        aged={}; dead=[]
        for cid, age in self.db.items():
            na=age+1
            if na>=DB_THRESHOLD: dead.append(cid)
            else: aged[cid]=na
        dead.sort(key=lambda c: len(self.store.get(c, ())))
        deleted=[]
        for cid in dead:
            if cid in self.db: del self.db[cid]
            uid=self.uid_of.get(cid)
            self._kill_composition(cid, inline_log=inline_log)
            if self.backflow_failure: break
            deleted.append({"cid":cid,"uid":uid})
        for cid, age in aged.items(): self.db[cid]=age
        return deleted

    def _kill_composition(self, cid, inline_log=None):
        if cid not in self.store: return
        content=self.store[cid]
        # record the inline event: dying comp + its referencing parents with before content
        if inline_log is not None:
            refs=[r for r in self.rdeps.get(cid,set()) if r in self.store]
            inline_log.append({
                "dying":cid,"dying_uid":self.uid_of.get(cid),
                "dying_content":list(content),
                "refs":[{"cid":r,"before":list(self.store[r])} for r in refs],
            })
        for ref_cid in list(self.rdeps.get(cid,set())):
            if ref_cid not in self.store: continue
            oc=self.store[ref_cid]; rc=oc.count(cid)
            nl=len(oc)-rc+rc*len(content)
            if nl>MAX_INLINE_LEN: self.backflow_failure=True; return
            nc=[]
            for tok in oc:
                if tok==cid: nc.extend(content)
                else: nc.append(tok)
            nt=tuple(nc)
            if oc in self.reverse: del self.reverse[oc]
            self.store[ref_cid]=nt; self.reverse[nt]=ref_cid
            self.deps[ref_cid].discard(cid)
            cd=self.deps.get(cid,set()); self.deps[ref_cid].update(cd)
            for dep in cd:
                if dep in self.rdeps: self.rdeps[dep].add(ref_cid)
            # fill in 'after' for the matching ref in the log
            if inline_log is not None:
                for ent in inline_log:
                    if ent["dying"]==cid:
                        for rr in ent["refs"]:
                            if rr["cid"]==ref_cid: rr["after"]=list(nt)
        for dep in self.deps.get(cid,set()):
            if dep in self.rdeps: self.rdeps[dep].discard(cid)
        ck=self.store[cid]
        if ck in self.reverse: del self.reverse[ck]
        del self.store[cid]
        if cid in self.deps: del self.deps[cid]
        if cid in self.rdeps: del self.rdeps[cid]
        if cid in self.mco: self.mco.remove(cid)
        if cid in self.pr: self.pr.remove(cid)
        if cid in self.uid_of: del self.uid_of[cid]
        self.reuse_pool.append(cid)

    def try_capture(self, content_tuple):
        if len(content_tuple)<MIN_CAPTURE_LEN: return None, False
        if content_tuple in self.reverse: return self.reverse[content_tuple], False
        cid=self.reuse_pool.pop() if self.reuse_pool else self.next_id
        if cid==self.next_id: self.next_id+=1
        self.store[cid]=content_tuple; self.reverse[content_tuple]=cid
        referenced=set(t for t in content_tuple if t>=FIRST_COMP_ID)
        self.deps[cid]=referenced; self.rdeps.setdefault(cid,set())
        for ref in referenced: self.rdeps.setdefault(ref,set()).add(cid)
        self.mco.append(cid); self.pr_register(cid)
        self.uid_of[cid]=self.next_uid; self.next_uid+=1
        return cid, True

    def size(self): return len(self.store)

    def mco_probs(self):
        """Within-stack selection probability for each composition:
        P(m_j) = decay^(rank_from_top) normalized over the stack.
        Returns {cid: prob}."""
        n=len(self.mco)
        if n==0: return {}
        weights=[MCO_DECAY**(n-j-1) for j in range(n)]  # index j, newest at end
        total=sum(weights)
        return {self.mco[j]: weights[j]/total for j in range(n)}

    def sample_composition(self, rng):
        n=len(self.mco)
        if n==0: return None
        weights=[MCO_DECAY**(n-j-1) for j in range(n)]
        total=sum(weights); roll=rng.random()*total; cum=0.0
        for j in range(n):
            cum+=weights[j]
            if roll<=cum: return self.mco[j]
        return self.mco[-1]


def sample_token(rng, mg):
    if mg.size()==0 or rng.random()<BASE_GENE_PROB:
        return rng.choice([ENC_BASE0, ENC_BASE1])
    return mg.sample_composition(rng)

def init_population(rng):
    return [[rng.choice([ENC_BASE0,ENC_BASE1]) for _ in range(rng.randint(MIN_LEN,MAX_LEN))]
            for _ in range(POPULATION_SIZE)]

def is_delimiter(t): return t in (ENC_OPEN, ENC_CLOSE)
def is_base(t): return t in (ENC_BASE0, ENC_BASE1)
def is_comp(t): return t >= FIRST_COMP_ID

def assert_invariants(org):
    inside=False
    for tok in org:
        if tok==ENC_OPEN:
            if inside: raise AssertionError("Nesting")
            inside=True
        elif tok==ENC_CLOSE:
            if not inside: raise AssertionError("Unmatched close")
            inside=False
        elif tok<ENC_BASE0: raise AssertionError("Unknown")
    if inside: raise AssertionError("Unmatched open")

def remove_pair_at(org, idx):
    if org[idx]==ENC_OPEN:
        j=idx+1
        while j<len(org) and org[j]!=ENC_CLOSE: j+=1
        if j>=len(org): raise AssertionError("open rm")
        del org[j]; del org[idx]; return max(idx-1,0)
    if org[idx]==ENC_CLOSE:
        j=idx-1
        while j>=0 and org[j]!=ENC_OPEN: j-=1
        if j<0: raise AssertionError("close rm")
        del org[idx]; del org[j]; return max(j-1,0)
    raise AssertionError("non-delim")

def find_delimiters(org, index):
    s=None
    for i in range(index,-1,-1):
        if org[i]==ENC_OPEN: s=i; break
    if s is None: return None,None
    e=None
    for j in range(s+1,len(org)):
        if org[j]==ENC_CLOSE: e=j; break
    return s,e

def calculate_depth(org, index):
    d=0
    for c in org[:index+1]:
        if c==ENC_OPEN: d+=1
        elif c==ENC_CLOSE: d-=1
    return d

def attempt_capture(org, interior_idx, mg, events, host_id=None):
    s,e=find_delimiters(org, interior_idx)
    if s is None or e is None: return False
    content=tuple(org[s+1:e])
    before=list(org)
    cid,is_new=mg.try_capture(content)
    if cid is None: return False
    org[s:e+1]=[cid]
    if is_new:
        events["captures"].append({
            "cid":cid,"uid":mg.uid_of.get(cid),"content":list(content),
            "span":[s,e],
            "host_before":before[:80],   # cap for size
            "host_after":list(org)[:80],
            "host_id":host_id,
        })
    return True

def can_swap(a,b): return not (is_delimiter(a) and is_delimiter(b))
def attempt_swap(org,i,rng):
    if len(org)<2: return i,False
    dirs=[1,-1] if rng.random()<0.5 else [-1,1]
    for d in dirs:
        j=i+d
        if 0<=j<len(org) and can_swap(org[i],org[j]):
            org[i],org[j]=org[j],org[i]; return j,True
    return i,False

def mutate_org(org, mg, rng, events, track_reuse=False, host_id=None):
    mev=events.setdefault("mut_by_org",{}).setdefault(host_id,[])
    # per-edit trace: list of {type,pos,seq(after edit)} — only kept if structural happens
    trace=events.setdefault("edit_trace",{}).setdefault(host_id,[])
    STRUCTURAL={"capture","open","insert_delimiter","delimit_delete","swap_boundary"}
    def rec(kind,pos,extra=None):
        e={"type":kind,"pos":pos}
        if extra: e.update(extra)
        mev.append(e)
        te={"type":kind,"pos":pos,"seq":org[:60],"structural":kind in STRUCTURAL}
        if extra: te.update(extra)
        trace.append(te)
    i=0
    while i<len(org):
        tok=org[i]; depth=calculate_depth(org,i); roll=rng.random()
        if is_delimiter(tok):
            # A2 context: only delimit_delete (at pi6) or swap (at full A1 rate) are
            # legal; point/insert/delete would corrupt the boundary token, so swap is
            # the sole general mutation and takes the whole A1 budget. Else no-op.
            if roll<BOUNDARY_REMOVE_PROB:
                if len(org)-2>=MIN_LEN: i=remove_pair_at(org,i); rec("delimit_delete",i); continue
                else: i+=1; continue
            elif roll<BOUNDARY_REMOVE_PROB+DELIMITED_MUTATION_PROB:
                ni,ds=attempt_swap(org,i,rng)
                if ds: rec("swap_boundary",i); i=ni
                i+=1; continue
            else:
                i+=1; continue   # no-op
        if depth==0:
            ow=OPEN_PROB if (is_comp(tok) and tok in mg.store) else 0.0
            t0=BOUNDARY_INSERT_PROB; t1=t0+ow; t2=t1+MUTATION_PROB/4
            t3=t2+MUTATION_PROB/4; t4=t3+MUTATION_PROB/4; t5=t4+MUTATION_PROB/4
            if roll<t0:
                org.insert(i,ENC_OPEN); org.insert(i+2,ENC_CLOSE); rec("insert_delimiter",i); i+=1
            elif roll<t1:
                content=list(mg.store[tok]); exp=[ENC_OPEN]+content+[ENC_CLOSE]
                org[i:i+1]=exp; rec("open",i,{"cid":tok,"span_len":len(exp)}); i+=len(exp); events["opens"]+=1
            elif roll<t2:
                nt=sample_token(rng,mg)
                if track_reuse and is_comp(nt): events["reuses"].append(nt)
                org[i]=nt; rec("point",i,{"comp":nt if is_comp(nt) else None}); i+=1
            elif roll<t3:
                ni,ds=attempt_swap(org,i,rng)
                if ds: rec("swap",i); i=ni
                i+=1
            elif roll<t4:
                nt=sample_token(rng,mg)
                if track_reuse and is_comp(nt): events["reuses"].append(nt)
                if rng.random()<0.5: org.insert(i,nt); rec("insert",i,{"comp":nt if is_comp(nt) else None}); i+=1
                else: org.insert(i+1,nt); rec("insert",i+1,{"comp":nt if is_comp(nt) else None}); i+=2
            elif roll<t5:
                if len(org)>MIN_LEN: del org[i]; rec("delete",i); i=max(i-1,0)
                else: i+=1
            else: i+=1
            continue
        ow=OPEN_PROB
        t0=CAPTURE_PROB; t1=t0+ow; t2=t1+DELIMITED_MUTATION_PROB/4
        t3=t2+DELIMITED_MUTATION_PROB/4; t4=t3+DELIMITED_MUTATION_PROB/4; t5=t4+DELIMITED_MUTATION_PROB/4
        if roll<t0:
            if attempt_capture(org,i,mg,events,host_id=host_id): rec("capture",i); i+=1; continue
            i+=1
        elif roll<t1:
            if is_comp(tok) and tok in mg.store:
                content=list(mg.store[tok]); org[i:i+1]=content; rec("open",i,{"cid":tok,"span_len":len(content)}); i+=len(content); events["opens"]+=1
            else: i+=1
        elif roll<t2:
            nt=sample_token(rng,mg)
            if track_reuse and is_comp(nt): events["reuses"].append(nt)
            org[i]=nt; rec("point",i,{"comp":nt if is_comp(nt) else None}); i+=1
        elif roll<t3:
            ni,ds=attempt_swap(org,i,rng)
            if ds: rec("swap",i); i=ni
            i+=1
        elif roll<t4:
            nt=sample_token(rng,mg)
            if track_reuse and is_comp(nt): events["reuses"].append(nt)
            if rng.random()<0.5: org.insert(i,nt); rec("insert",i,{"comp":nt if is_comp(nt) else None}); i+=1
            else: org.insert(i+1,nt); rec("insert",i+1,{"comp":nt if is_comp(nt) else None}); i+=2
        elif roll<t5:
            if len(org)>MIN_LEN: del org[i]; rec("delete",i); i=max(i-1,0)
            else: i+=1
        else: i+=1
    assert_invariants(org)

def evaluate_fitness(org, mg):
    decoded, top = mg.decode(org)
    L=len(decoded)
    fit=min(L,FITNESS_THRESHOLD)-OVER_PENALTY*max(0,L-FITNESS_THRESHOLD)
    return fit, L, top

def evaluate_population(pop, mg):
    return [evaluate_fitness(o,mg) for o in pop]

def make_next_generation_l6(pop, evals, rng):
    ranked=sorted(range(len(pop)), key=lambda i: evals[i][0], reverse=True)
    n_elite=max(1,int(ELITE_FRAC*POPULATION_SIZE))
    n_par=min(NUM_PARENTS,len(ranked))
    elite=[pop[ranked[i]].copy() for i in range(min(n_elite,len(ranked)))]
    parents=[pop[ranked[i]].copy() for i in range(n_par)]
    parent_ids=ranked[:n_par]
    survivor_idx=set(ranked[:max(n_par,n_elite)])
    survivor_top=set()
    for idx in survivor_idx: survivor_top |= evals[idx][2]
    next_pop=list(elite)
    offspring_parent=[None]*n_elite   # elites have no parent (they ARE survivors)
    while len(next_pop)<POPULATION_SIZE:
        p=rng.randrange(len(parents))
        next_pop.append(parents[p].copy())
        offspring_parent.append(parent_ids[p])
    sel={"ranked":ranked,"n_elite":n_elite,"parent_ids":parent_ids,
         "offspring_parent":offspring_parent}
    return next_pop, n_elite, survivor_top, sel

def compute_light_stats(pop, mg, evals):
    base=comp=0; freq={}
    for org in pop:
        for tok in org:
            if is_delimiter(tok): continue
            if is_base(tok): base+=1
            else: comp+=1; freq[tok]=freq.get(tok,0)+1
    nd=base+comp
    comp_frac=comp/nd if nd else 0.0
    dom_frac=(max(freq.values())/nd) if (freq and nd) else 0.0
    fits=[e[0] for e in evals]; dls=[e[1] for e in evals]
    return comp_frac, dom_frac, sum(fits)/len(fits), sum(dls)/len(dls)

def population_presence(pop, mg, topk=24):
    """Return (salient_cids, matrix) where matrix[o] is the set (as sorted list)
    of salient metagenes carried by organism o. Salient = top-K by population
    prevalence among top-level composition tokens."""
    freq={}
    org_comps=[]
    for org in pop:
        s=set(t for t in org if t>=FIRST_COMP_ID and t in mg.store)
        org_comps.append(s)
        for c in s: freq[c]=freq.get(c,0)+1
    salient=sorted(freq, key=lambda c:freq[c], reverse=True)[:topk]
    sal_index={c:i for i,c in enumerate(salient)}
    # per-organism bitmask over salient (compact: list of salient-indices present)
    matrix=[]
    for s in org_comps:
        matrix.append(sorted(sal_index[c] for c in s if c in sal_index))
    prevalence={c:freq[c] for c in salient}
    return salient, matrix, prevalence

def emit_mg(mg):
    """Emit a capped view of the metagenome, closed under references so the
    DAG is self-consistent (every edge endpoint is present)."""
    out={}
    seed=list(mg.store.keys())[-MAX_MG_EMIT:]
    # closure: include everything the seeded set references, transitively
    ids=set(seed); stack=list(seed)
    while stack:
        c=stack.pop()
        for t in mg.store.get(c, ()):
            if t>=FIRST_COMP_ID and t in mg.store and t not in ids:
                ids.add(t); stack.append(t)
    for cid in ids:
        out[str(cid)]={
            "content":list(mg.store[cid]),
            "depth":mg.depth_of(cid),
            "flatlen":mg.flatlen(cid),
            "in_pr":cid in mg.pr,
            "in_db":cid in mg.db,
            "db_age":mg.db.get(cid,0),
        }
    return out

def snapshot_mg(mg):
    probs=mg.mco_probs()
    out={}
    for cid in list(mg.store.keys()):
        out[str(cid)]={
            "content":list(mg.store[cid]),
            "depth":mg.depth_of(cid),
            "flatlen":mg.flatlen(cid),
            "in_pr":cid in mg.pr,
            "in_db":cid in mg.db,
            "db_age":mg.db.get(cid,0),
            "mco_p":round(probs.get(cid,0.0),3),
            "uid":mg.uid_of.get(cid),
            "refs":[t for t in mg.store[cid] if t>=FIRST_COMP_ID],
        }
    return out

def run_movie():
    """Phase-level beat emission. Each beat is a fully consistent snapshot
    (pop+mg+pr+db at that instant) tagged with phase/gen/narration/highlight.
    Beats per generation: start, selection, mutation (sub-beats per capture),
    participation, deletion. Causality is never off-by-one because every beat
    shows the state AT that beat."""
    rng=random.Random(SEED); mg=MetaGenome(); pop=init_population(rng)
    beats=[]
    t0=time.time()

    def emit(gen, phase, narr, highlight=None, extra=None, pop_override=None, focus_org=None, edit_pos=None):
        evals=evaluate_population(pop,mg)
        popdata=[list(o) for o in pop]
        if pop_override is not None and focus_org is not None:
            popdata[focus_org]=list(pop_override)   # show this org's mid-pass sequence
        b={
            "gen":gen,"phase":phase,"narr":narr,
            "pop":popdata,
            "fit":[e[0] for e in evals],
            "dlen":[e[1] for e in evals],
            "mg":snapshot_mg(mg),
            "mg_size":mg.size(),
            "pr":list(mg.pr),
            "db":{str(k):v for k,v in mg.db.items()},
            "reuse":len(mg.reuse_pool),
            "highlight":highlight or {},
        }
        if focus_org is not None: b["focus_org"]=focus_org
        if edit_pos is not None: b["edit_pos"]=edit_pos
        if extra: b.update(extra)
        beats.append(b)

    for gen in range(GENERATIONS+1):
        # ---- BEAT: start of generation ----
        evals=evaluate_population(pop,mg)
        mf=sum(e[0] for e in evals)/len(evals)
        mdl=sum(e[1] for e in evals)/len(evals)
        emit(gen,"start",
             f"Generation {gen} begins. {len(pop)} organisms, mean length {mdl:.0f} (target {FITNESS_THRESHOLD}).")

        if gen>=GENERATIONS: break

        # ---- SELECTION, made visible in two beats ----
        # Beat 1: RANKING — still showing the CURRENT population, with the
        # chosen parents/elites marked by fitness rank. Nothing replaced yet.
        ranked=sorted(range(len(pop)), key=lambda i: evals[i][0], reverse=True)
        n_elite_pre=max(1,int(ELITE_FRAC*POPULATION_SIZE))
        n_par_pre=min(NUM_PARENTS,len(ranked))
        rank_hl={}
        for r,oi in enumerate(ranked):
            if r<n_elite_pre: rank_hl[oi]="var(--e-rescue)"      # elite
            elif r<n_par_pre: rank_hl[oi]="var(--e-reuse)"       # parent
            # others left unmarked = not selected, will be replaced
        emit(gen,"selection",
             f"Selection: organisms ranked by fitness. The top {n_par_pre} (blue) become parents; "
             f"the top {n_elite_pre} (green) also carry over unchanged as elite. The rest will be replaced by "
             f"mutated clones of the parents — there is no crossover, so a parent is copied whole.",
             highlight={"orgs":rank_hl})

        # now actually form the next generation
        pop,ne,survivor_top,sel=make_next_generation_l6(pop,evals,rng)
        byParent={}
        for off,p in enumerate(sel["offspring_parent"]):
            if p is not None: byParent.setdefault(p,[]).append(off)
        # Beat 2: CLONES — new population formed (pre-mutation). Show which are
        # elite (unchanged) vs clones (about to be mutated).
        clone_hl={i:"var(--e-rescue)" for i in range(ne)}
        emit(gen,"breeding",
             f"Next generation formed: {ne} elite carried over unchanged (green); the remaining "
             f"{len(pop)-ne} are exact clones of selected parents, about to be mutated. "
             f"These are identical copies — any differences you see next come only from mutation.",
             highlight={"orgs":clone_hl},
             extra={"selection":sel})

        # ---- MUTATION ----
        ev={"captures":[],"reuses":[],"rescues":[],"deletions":[],"opens":0,
            "mut_by_org":{}, "inlines":[], "selection":sel, "edit_trace":{}}
        for k,org in enumerate(pop):
            if k<ne: continue
            mutate_org(org, mg, rng, ev, track_reuse=True, host_id=k)
            trace=ev["edit_trace"].get(k,[])
            # find index of last structural edit; only replay up to there (+1 context)
            struct_idxs=[ii for ii,t in enumerate(trace) if t["structural"]]
            has_structural=bool(struct_idxs)
            if has_structural:
                last_struct=struct_idxs[-1]
                first_struct=struct_idxs[0]
                WIN=5
                start=max(0, first_struct-WIN)
                replay=trace[start:last_struct+1]
                NICE={"point":"point mutation","insert":"insertion","delete":"deletion",
                      "swap":"swap","swap_boundary":"boundary swap (a delimiter moves)",
                      "insert_delimiter":"a new delimited region opens",
                      "delimit_delete":"a delimiter pair is removed",
                      "open":"a composition is opened back into its parts",
                      "capture":"CAPTURE — the delimited region becomes one reusable M"}
                cap_events=[c for c in ev["captures"] if c.get("host_id")==k]
                cap_seen=0
                for ti,t in enumerate(replay):
                    pos=t["pos"]
                    if t["type"]=="capture":
                        ce=cap_events[cap_seen] if cap_seen<len(cap_events) else None
                        cap_seen+=1
                        if ce is None:
                            # dedup capture (matched an existing M, no new birth) — skip
                            continue
                        cid=ce["cid"]; span=ce["span"]; before=ce["host_before"]
                        content=ce["content"]
                        # BEAT 1: show the region about to be captured, highlighted
                        emit(gen,"capture_pre",
                             f"Org {k}: a bounded region <b>( {tokens_str(content)} )</b> at positions {span[0]}–{span[1]} is about to be captured.",
                             highlight={"orgs":{k:"var(--e-capture)"},"region":[k,span[0],span[1]]},
                             pop_override=before, focus_org=k, edit_pos=span[0])
                        # BEAT 2: it has collapsed into the new M
                        emit(gen,"capture",
                             f"Org {k}: <b>capture</b> — that region is now the single reusable unit M{cid}. It enters the metagenome and any organism can reuse it.",
                             highlight={"orgs":{k:"var(--e-capture)"},"cids":{cid:"var(--e-capture)"}},
                             pop_override=t["seq"], focus_org=k, edit_pos=pos)
                        continue
                    elif t["type"]=="insert_delimiter":
                        narr=f"Org {k}: a new boundary pair is created at positions {pos} and {pos+2}."
                        hl={"orgs":{k:"var(--e-delim)"}}
                        ph="edit"
                    elif t["type"]=="swap_boundary":
                        narr=f"Org {k}: a boundary swaps with its neighbor at position {pos}."
                        hl={"orgs":{k:"var(--e-swapb)"}}
                        ph="edit"
                    elif t["type"]=="delimit_delete":
                        narr=f"Org {k}: a boundary pair is removed at position {pos}."
                        hl={"orgs":{k:"var(--e-delim)"}}
                        ph="edit"
                    elif t["type"]=="open":
                        sl=t.get("span_len",1)
                        narr=f"Org {k}: composition M{t.get('cid','?')} is opened back into its {sl} parts at position {pos} — the abstraction is unpacked inline."
                        hl={"orgs":{k:"var(--e-open)"},"editspan":[pos,pos+sl-1]}
                        ph="edit"
                    else:
                        nice={"point":"point mutation","insert":"insertion","delete":"deletion","swap":"swap"}.get(t["type"],t["type"])
                        narr=f"Org {k}: {nice} at position {pos}."
                        hl={"orgs":{k:"var(--e-point)"}}
                        ph="edit"
                    emit(gen,ph,narr,highlight=hl,pop_override=t["seq"],focus_org=k,edit_pos=pos)
        # ---- BEAT: mutation pass complete across the whole population ----
        reuse_cids=set(ev["reuses"])
        emit(gen,"mutation",
             f"Mutation pass complete across all {len(pop)} organisms. "
             + (f"{len(ev['captures'])} capture(s) this generation; " if ev['captures'] else "")
             + ("reused compositions spread between organisms with no crossover — the metagenome is the only cross-lineage channel." if reuse_cids else "mostly routine base-gene edits elsewhere."),
             highlight={"cids":{c:"var(--e-reuse)" for c in reuse_cids},
                        "mut_by_org":{str(kk):vv for kk,vv in ev["mut_by_org"].items()}},
             extra={"events":{
                 "captures":ev["captures"],"reuses":ev["reuses"],
                 "mut_by_org":{str(kk):vv for kk,vv in ev["mut_by_org"].items()},
                 "opens":ev["opens"]}})

        # ---- PARTICIPATION (rescue/refresh) ----
        rescued=[]
        for cid in survivor_top:
            if cid in mg.pr: mg.pr_refresh(cid)
            elif cid in mg.db:
                if mg.db_rescue(cid): rescued.append(cid)
        at_risk=len(mg.db)   # remaining in deletion basket after rescues, before the tick
        if rescued:
            pnarr=(f"Participation: {len(rescued)} composition(s) used by surviving organisms were pulled back "
                   f"out of the deletion basket. {at_risk} still at risk of deletion.")
        elif at_risk:
            pnarr=(f"Participation: survivors' usage kept active compositions current. "
                   f"{at_risk} composition(s) at risk of deletion — unused, sitting in the basket.")
        else:
            pnarr="Participation: survivors' usage kept active compositions current. None at risk of deletion."
        emit(gen,"participation", pnarr,
             highlight={"cids":{c:"var(--e-rescue)" for c in rescued}})

        # ---- DELETION / INLINE ----
        inl=[]
        deleted=mg.db_tick(inline_log=inl)
        del_cids={d["cid"]:"var(--e-delete)" for d in deleted}
        ref_inl=[x for x in inl if x["refs"] and any("after" in r for r in x["refs"])]
        if deleted:
            narr_d=(f"{len(deleted)} composition(s) went unused, aged out, and were inlined away — "
                    f"information pushed back up the hierarchy. Construction balanced by dissipation.")
            if ref_inl:
                narr_d+=" See the rewrite below the metagenome — a referenced composition's parents update in place."
        else:
            narr_d="No deletions this step."
        emit(gen,"deletion",narr_d,
             highlight={"cids":del_cids},
             extra={"events":{"deletions":deleted,"inlines":inl}})

        if mg.backflow_failure:
            print(f"backflow at {gen+1}"); break

    payload={
        "meta":{"pop":POPULATION_SIZE,"gens":GENERATIONS,"seed":SEED,
                "threshold":FITNESS_THRESHOLD,"pr_capacity":PR_CAPACITY,
                "capture_prob":CAPTURE_PROB,"open_prob":OPEN_PROB,
                "crossover":ENABLE_CROSSOVER,"movie":True,
                "legend":{"0":"(","1":")","2":"a","3":"b"}},
        "beats":beats,
    }
    with open(LOG_PATH,"w") as f:
        json.dump(payload,f)
    print(f"wrote {LOG_PATH}  beats={len(beats)}  bytes={os.path.getsize(LOG_PATH)}  t={time.time()-t0:.1f}s")

def tokens_str(toks):
    out=[]
    for t in toks:
        if t==0: out.append("(")
        elif t==1: out.append(")")
        elif t==2: out.append("a")
        elif t==3: out.append("b")
        else: out.append("M"+str(t))
    return " ".join(out)

def run():
    rng=random.Random(SEED); mg=MetaGenome(); pop=init_population(rng)
    frames=[]
    events={"captures":[],"reuses":[],"rescues":[],"deletions":[],"opens":0,
            "mut_by_org":{}, "inlines":[], "selection":None}
    t0=time.time()
    for gen in range(GENERATIONS+1):
        evals=evaluate_population(pop,mg)
        cf,df,mf,mdl=compute_light_stats(pop,mg,evals)
        probs=mg.mco_probs()
        # full MG with MCO prob to 3dp
        mg_full={}
        seed=list(mg.store.keys())
        for cid in seed:
            mg_full[str(cid)]={
                "content":list(mg.store[cid]),
                "depth":mg.depth_of(cid),
                "flatlen":mg.flatlen(cid),
                "in_pr":cid in mg.pr,
                "in_db":cid in mg.db,
                "db_age":mg.db.get(cid,0),
                "mco_p":round(probs.get(cid,0.0),3),
                "uid":mg.uid_of.get(cid),
                "refs":[t for t in mg.store[cid] if t>=FIRST_COMP_ID],
            }
        frame={
            "gen":gen,
            "pop":[list(o) for o in pop],                 # ALL organisms, full
            "fit":[e[0] for e in evals],
            "dlen":[e[1] for e in evals],
            "mg":mg_full,
            "mg_size":mg.size(),
            "pr":list(mg.pr),                             # bottom->top
            "db":{str(k):v for k,v in mg.db.items()},
            "reuse":len(mg.reuse_pool),
            "events":{
                "captures":events["captures"],
                "reuses":events["reuses"],
                "rescues":events["rescues"],
                "deletions":events["deletions"],
                "inlines":events["inlines"],
                "mut_by_org":{str(k):v for k,v in events["mut_by_org"].items()},
                "opens":events["opens"],
            },
            "selection":events["selection"],   # how THIS gen's pop was formed
            "stats":{"mean_fit":round(mf,1),"mean_dlen":round(mdl,1),
                     "dom_frac":round(df,3),"comp_frac":round(cf,3)},
        }
        frames.append(frame)
        events={"captures":[],"reuses":[],"rescues":[],"deletions":[],"opens":0,
                "mut_by_org":{}, "inlines":[], "selection":None}
        if gen<GENERATIONS:
            pop,ne,survivor_top,sel=make_next_generation_l6(pop,evals,rng)
            events["selection"]=sel
            for k,org in enumerate(pop):
                if k<ne: continue  # elites unmutated
                mutate_org(org, mg, rng, events, track_reuse=True, host_id=k)
            for cid in survivor_top:
                if cid in mg.pr: mg.pr_refresh(cid)
                elif cid in mg.db:
                    if mg.db_rescue(cid): events["rescues"].append(cid)
            deleted=mg.db_tick(inline_log=events["inlines"])
            events["deletions"].extend(deleted)
            if mg.backflow_failure:
                print(f"backflow at {gen+1}"); break
    payload={
        "meta":{"pop":POPULATION_SIZE,"gens":GENERATIONS,"seed":SEED,
                "threshold":FITNESS_THRESHOLD,"pr_capacity":PR_CAPACITY,
                "capture_prob":CAPTURE_PROB,"open_prob":OPEN_PROB,
                "crossover":ENABLE_CROSSOVER,
                "legend":{"0":"(","1":")","2":"a","3":"b"}},
        "frames":frames,
    }
    with open(LOG_PATH,"w") as f:
        json.dump(payload,f)
    sz=os.path.getsize(LOG_PATH)
    print(f"wrote {LOG_PATH}  frames={len(frames)}  bytes={sz}  t={time.time()-t0:.1f}s")
    # quick textual scan for a good capture->reuse window
    for fr in frames:
        nc=len(fr["events"]["captures"]); nr=len(fr["events"]["reuses"])
        nrescue=len(fr["events"]["rescues"]); nd=len(fr["events"]["deletions"])
        if nc or nr or nrescue or nd:
            pass
    print("done")

if __name__=="__main__":
    if os.environ.get("MOVIE","1")=="1":
        run_movie()
    else:
        run()
