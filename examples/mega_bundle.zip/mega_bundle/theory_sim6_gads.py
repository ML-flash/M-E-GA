"""
theory_sim6_gads.py

Layer 6 rebuilt from intact Layer 5, following GADS theory EXPLICITLY:
  - Deletion is participation-GATED with rescue (GADS Chain 3 + Chain 4),
    NOT blind age-based (that was PFOL A3.4, the wrong spec for this build).
  - PR is participation-ordered: composition found in survivors moves to
    retention boundary (Chain 3, "move to retention boundary on participation").
  - DB rescue: a displaced composition that receives a usage signal during
    the buffer period is rescued back to PR instead of aging to death
    (Chain 4). Deletion only at age >= pi15=2 with zero signals = proof of absence.
  - Participation signal S(t) = top-level composition tokens referenced by the
    WHOLE population at time t, gathered in a single comprehensive pass during
    fitness-evaluation decode (Chain 3/4: usage signals are emitted when every
    organism is decoded for evaluation, before culling). The decode pass over the
    generation provides the participation signal for every gene in one sweep.
  - CROSSOVER OFF: recombination channel is the shared metagenome, not splicing.

Parameters carried from intact Layer 5 (NOT the corrupted Layer 6):
  MUTATION_PROB=0.05, DELIMITED_MUTATION_PROB=0.02, MAX_INLINE_LEN=80000.

Layer 6 additions: Decode, F(x)=min(L,T)-2*max(0,L-T), fitness-ranked
selection, elitism.

CORRECTION (boundary-swap rate): the A2 (delimiter) mutation branch previously
attempted a swap with prob (1 - BOUNDARY_REMOVE_PROB) ~= 0.998, i.e. nearly every
delimiter the mutation index passed got swapped. Per spec, the only general
mutation legal on a delimiter is swap (point/insert/delete would corrupt the
boundary token), and it fires at the full A1 rate (DELIMITED_MUTATION_PROB), with
the remainder a no-op. Now: delimit_delete at BOUNDARY_REMOVE_PROB, else swap at
DELIMITED_MUTATION_PROB, else no-op. This drastically lowers boundary churn.
"""

import os, random, math, time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- PARAMETERS (from intact Layer 5) ----
POPULATION_SIZE = int(os.environ.get("POP", "500"))
GENERATIONS     = int(os.environ.get("GENS", "5000"))
SEED            = int(os.environ.get("SEED", "1"))
PROGRESS_EVERY  = int(os.environ.get("PROGRESS_EVERY", "20"))

MIN_LEN = 2
MAX_LEN = 100

ENABLE_CROSSOVER = False          # GADS: OFF — recombination via metagenome
NUM_PARENTS      = int(os.environ.get("PARENTS","200"))
CROSSOVER_PROB   = 0.50           # unused when crossover off

BOUNDARY_INSERT_PROB = 0.0035
BOUNDARY_REMOVE_PROB = 0.0020

CAPTURE_PROB = 0.09
MIN_CAPTURE_LEN = 2

MUTATION_PROB           = 0.05    # L5 value (corrupted-6 had 0.10)
DELIMITED_MUTATION_PROB = 0.02    # L5 value (corrupted-6 had 0.05)

OPEN_PROB = 0.005
SINGULARITY_THRESHOLD = 0.95
BASE_GENE_PROB = 0.57
MCO_DECAY = 0.90

PR_CAPACITY = 50          # pi14
DB_THRESHOLD = 2          # pi15 (proof-of-absence)
MAX_INLINE_LEN = 80000    # L5 value (corrupted-6 had 10000)

ELITE_FRAC = 0.02
FITNESS_THRESHOLD = int(os.environ.get("FT","1000"))
OVER_PENALTY = 2
MAX_DECODE_DEPTH = 100

ENC_OPEN, ENC_CLOSE, ENC_BASE0, ENC_BASE1, FIRST_COMP_ID = 0, 1, 2, 3, 4
OUTPUT_FOLDER = os.environ.get("OUT", "theory_sim_6_gads")


class MetaGenome:
    def __init__(self):
        self.store={}; self.reverse={}; self.next_id=FIRST_COMP_ID
        self.deps={}; self.rdeps={}; self.mco=[]; self.reuse_pool=[]
        self.pr=[]            # participation register: index 0 = displacement boundary, end = retention boundary
        self.db={}            # cid -> age
        self.backflow_failure=False

    # ---- Decode (Layer 6) ----
    def decode(self, org):
        top=set(); result=[]
        for tok in org:
            if tok in (ENC_OPEN, ENC_CLOSE): continue
            elif tok >= FIRST_COMP_ID:
                top.add(tok); result.extend(self._expand(tok,0))
            else: result.append(tok)
        return result, top

    def _expand(self, cid, depth):
        if depth >= MAX_DECODE_DEPTH: return []
        if cid not in self.store: return []
        out=[]
        for tok in self.store[cid]:
            if tok in (ENC_OPEN, ENC_CLOSE): continue
            elif tok >= FIRST_COMP_ID: out.extend(self._expand(tok, depth+1))
            else: out.append(tok)
        return out

    # ---- PR (GADS Chain 3) ----
    def pr_register(self, cid):
        """New capture enters at retention boundary (top)."""
        if cid in self.pr: 
            self.pr_refresh(cid); return
        if len(self.pr) >= PR_CAPACITY:
            self._pr_displace()
        self.pr.append(cid)

    def pr_refresh(self, cid):
        """Chain 3: the only admissible positional update is
        'move to retention boundary on participation.'"""
        if cid in self.pr:
            self.pr.remove(cid)
            self.pr.append(cid)

    def _pr_displace(self):
        if not self.pr: return
        victim = self.pr.pop(0)   # displacement boundary = oldest-participation end
        self.db[victim] = 0       # enters DB at age 0

    # ---- DB (GADS Chain 4: rescue + proof-of-absence deletion) ----
    def db_rescue(self, cid):
        """Chain 4: usage signal during buffer period rescues back to PR."""
        if cid in self.db:
            del self.db[cid]
            # re-enter PR at retention boundary (may displace someone else)
            if len(self.pr) >= PR_CAPACITY:
                self._pr_displace()
            self.pr.append(cid)
            return True
        return False

    def db_tick(self):
        """Age DB residents. Delete those reaching pi15 with NO rescue this cycle.
        Rescues are applied separately (before tick) via db_rescue from S(t)."""
        aged={}; dead=[]
        for cid, age in self.db.items():
            na = age + 1
            if na >= DB_THRESHOLD:
                dead.append(cid)
            else:
                aged[cid] = na
        dead.sort(key=lambda c: len(self.store.get(c, ())))
        deleted=[]
        for cid in dead:
            if cid in self.db: del self.db[cid]
            self._kill_composition(cid)
            if self.backflow_failure: break
            deleted.append(cid)
        for cid, age in aged.items(): self.db[cid]=age
        return deleted

    # ---- Inlining + death (Chain 5) ----
    def _kill_composition(self, cid):
        if cid not in self.store: return
        content = self.store[cid]
        for ref_cid in list(self.rdeps.get(cid, set())):
            if ref_cid not in self.store: continue
            oc = self.store[ref_cid]
            rc = oc.count(cid)
            nl = len(oc) - rc + rc*len(content)
            if nl > MAX_INLINE_LEN:
                self.backflow_failure = True; return
            nc=[]
            for tok in oc:
                if tok == cid: nc.extend(content)
                else: nc.append(tok)
            nt=tuple(nc)
            if oc in self.reverse: del self.reverse[oc]
            self.store[ref_cid]=nt; self.reverse[nt]=ref_cid
            self.deps[ref_cid].discard(cid)
            cd=self.deps.get(cid,set())
            self.deps[ref_cid].update(cd)
            for dep in cd:
                if dep in self.rdeps: self.rdeps[dep].add(ref_cid)
        for dep in self.deps.get(cid,set()):
            if dep in self.rdeps: self.rdeps[dep].discard(cid)
        ck=self.store[cid]
        if ck in self.reverse: del self.reverse[ck]
        del self.store[cid]
        if cid in self.deps: del self.deps[cid]
        if cid in self.rdeps: del self.rdeps[cid]
        if cid in self.mco: self.mco.remove(cid)
        if cid in self.pr: self.pr.remove(cid)
        self.reuse_pool.append(cid)

    # ---- Capture (Chain 1, EA recycling Chain 6) ----
    def try_capture(self, content_tuple):
        if len(content_tuple) < MIN_CAPTURE_LEN: return None, False
        if content_tuple in self.reverse: return self.reverse[content_tuple], False
        cid = self.reuse_pool.pop() if self.reuse_pool else self.next_id
        if cid == self.next_id: self.next_id += 1
        self.store[cid]=content_tuple; self.reverse[content_tuple]=cid
        referenced = set(t for t in content_tuple if t >= FIRST_COMP_ID)
        self.deps[cid]=referenced; self.rdeps.setdefault(cid,set())
        for ref in referenced: self.rdeps.setdefault(ref,set()).add(cid)
        self.mco.append(cid); self.pr_register(cid)
        return cid, True

    def size(self): return len(self.store)
    def all_ids(self): return list(self.store.keys())

    def sample_composition(self, rng):
        n=len(self.mco)
        if n==0: return None
        weights=[MCO_DECAY**(n-j-1) for j in range(n)]
        total=sum(weights); roll=rng.random()*total; cum=0.0
        for j in range(n):
            cum+=weights[j]
            if roll<=cum: return self.mco[j]
        return self.mco[-1]


def sample_token(rng, mg):
    if mg.size()==0 or rng.random()<BASE_GENE_PROB:
        return rng.choice([ENC_BASE0, ENC_BASE1])
    return mg.sample_composition(rng)

def init_population(rng):
    return [[rng.choice([ENC_BASE0,ENC_BASE1]) for _ in range(rng.randint(MIN_LEN,MAX_LEN))]
            for _ in range(POPULATION_SIZE)]

def is_delimiter(t): return t in (ENC_OPEN, ENC_CLOSE)
def is_base(t): return t in (ENC_BASE0, ENC_BASE1)
def is_comp(t): return t >= FIRST_COMP_ID

def assert_invariants(org):
    inside=False
    for tok in org:
        if tok==ENC_OPEN:
            if inside: raise AssertionError("Nesting")
            inside=True
        elif tok==ENC_CLOSE:
            if not inside: raise AssertionError("Unmatched close")
            inside=False
        elif tok < ENC_BASE0: raise AssertionError("Unknown")
    if inside: raise AssertionError("Unmatched open")

def remove_pair_at(org, idx):
    if org[idx]==ENC_OPEN:
        j=idx+1
        while j<len(org) and org[j]!=ENC_CLOSE: j+=1
        if j>=len(org): raise AssertionError("open rm")
        del org[j]; del org[idx]; return max(idx-1,0)
    if org[idx]==ENC_CLOSE:
        j=idx-1
        while j>=0 and org[j]!=ENC_OPEN: j-=1
        if j<0: raise AssertionError("close rm")
        del org[idx]; del org[j]; return max(j-1,0)
    raise AssertionError("non-delim")

def find_delimiters(org, index):
    s=None
    for i in range(index,-1,-1):
        if org[i]==ENC_OPEN: s=i; break
    if s is None: return None,None
    e=None
    for j in range(s+1,len(org)):
        if org[j]==ENC_CLOSE: e=j; break
    return s,e

def calculate_depth(org, index):
    d=0
    for c in org[:index+1]:
        if c==ENC_OPEN: d+=1
        elif c==ENC_CLOSE: d-=1
    return d

def attempt_capture(org, interior_idx, mg, events):
    s,e=find_delimiters(org, interior_idx)
    if s is None or e is None: return False
    content=tuple(org[s+1:e])
    cid,is_new=mg.try_capture(content)
    if cid is None: return False
    org[s:e+1]=[cid]
    if is_new: events["captures"]+=1
    return True

def can_swap(a,b): return not (is_delimiter(a) and is_delimiter(b))

def attempt_swap(org,i,rng):
    if len(org)<2: return i,False
    dirs=[1,-1] if rng.random()<0.5 else [-1,1]
    for d in dirs:
        j=i+d
        if 0<=j<len(org) and can_swap(org[i],org[j]):
            org[i],org[j]=org[j],org[i]; return j,True
    return i,False

def mutate_org(org, mg, rng, events):
    i=0
    while i<len(org):
        tok=org[i]; depth=calculate_depth(org,i); roll=rng.random()
        if is_delimiter(tok):
            # A2 context: delimit_delete at pi6, else swap at full A1 rate
            # (swap is the only legal general mutation on a delimiter), else no-op.
            if roll<BOUNDARY_REMOVE_PROB:
                if len(org)-2>=MIN_LEN: i=remove_pair_at(org,i); continue
                else: i+=1; continue
            elif roll<BOUNDARY_REMOVE_PROB+DELIMITED_MUTATION_PROB:
                ni,ds=attempt_swap(org,i,rng)
                if ds: i=ni
                i+=1; continue
            else:
                i+=1; continue
        if depth==0:
            ow=OPEN_PROB if (is_comp(tok) and tok in mg.store) else 0.0
            t0=BOUNDARY_INSERT_PROB; t1=t0+ow; t2=t1+MUTATION_PROB/4
            t3=t2+MUTATION_PROB/4; t4=t3+MUTATION_PROB/4; t5=t4+MUTATION_PROB/4
            if roll<t0:
                org.insert(i,ENC_OPEN); org.insert(i+2,ENC_CLOSE); i+=1; events["baseline_bounds"]+=1
            elif roll<t1:
                content=list(mg.store[tok]); exp=[ENC_OPEN]+content+[ENC_CLOSE]
                org[i:i+1]=exp; i+=len(exp); events["opens"]+=1; events["open_bounds"]+=1
            elif roll<t2: org[i]=sample_token(rng,mg); i+=1
            elif roll<t3:
                ni,ds=attempt_swap(org,i,rng)
                if ds: i=ni
                i+=1
            elif roll<t4:
                nt=sample_token(rng,mg)
                if rng.random()<0.5: org.insert(i,nt); i+=1
                else: org.insert(i+1,nt); i+=2
            elif roll<t5:
                if len(org)>MIN_LEN: del org[i]; i=max(i-1,0)
                else: i+=1
            else: i+=1
            continue
        ow=OPEN_PROB
        t0=CAPTURE_PROB; t1=t0+ow; t2=t1+DELIMITED_MUTATION_PROB/4
        t3=t2+DELIMITED_MUTATION_PROB/4; t4=t3+DELIMITED_MUTATION_PROB/4; t5=t4+DELIMITED_MUTATION_PROB/4
        if roll<t0:
            if attempt_capture(org,i,mg,events): i+=1; continue
            i+=1
        elif roll<t1:
            if is_comp(tok) and tok in mg.store:
                content=list(mg.store[tok]); org[i:i+1]=content; i+=len(content); events["opens"]+=1
            else: i+=1
        elif roll<t2: org[i]=sample_token(rng,mg); i+=1
        elif roll<t3:
            ni,ds=attempt_swap(org,i,rng)
            if ds: i=ni
            i+=1
        elif roll<t4:
            nt=sample_token(rng,mg)
            if rng.random()<0.5: org.insert(i,nt); i+=1
            else: org.insert(i+1,nt); i+=2
        elif roll<t5:
            if len(org)>MIN_LEN: del org[i]; i=max(i-1,0)
            else: i+=1
        else: i+=1
    assert_invariants(org)

# ---- Layer 6: fitness / decode / selection ----
def evaluate_fitness(org, mg):
    decoded, top = mg.decode(org)
    L=len(decoded)
    fit = min(L,FITNESS_THRESHOLD) - OVER_PENALTY*max(0,L-FITNESS_THRESHOLD)
    return fit, L, top

def evaluate_population(pop, mg):
    return [evaluate_fitness(o,mg) for o in pop]

def make_next_generation_l6(pop, evals, rng):
    """Crossover OFF: offspring are mutated copies of fitness-ranked parents,
    elites preserved unmutated. Returns (next_pop, n_elite, survivor_top_comps)."""
    ranked=sorted(range(len(pop)), key=lambda i: evals[i][0], reverse=True)
    n_elite=max(1,int(ELITE_FRAC*POPULATION_SIZE))
    n_par = min(NUM_PARENTS, len(ranked))
    elite=[pop[ranked[i]].copy() for i in range(min(n_elite,len(ranked)))]
    parents=[pop[ranked[i]].copy() for i in range(n_par)]
    # Survivor participation set S(t): top-level comps in parents+elites
    survivor_idx = set(ranked[:max(n_par, n_elite)])
    survivor_top = set()
    for idx in survivor_idx:
        survivor_top |= evals[idx][2]
    next_pop=list(elite)
    while len(next_pop)<POPULATION_SIZE:
        next_pop.append(rng.choice(parents).copy())
    return next_pop, n_elite, survivor_top

def compute_light_stats(pop, mg, evals):
    base=comp=0; freq={}
    for org in pop:
        for tok in org:
            if is_delimiter(tok): continue
            if is_base(tok): base+=1
            else: comp+=1; freq[tok]=freq.get(tok,0)+1
    nd=base+comp
    comp_frac=comp/nd if nd else 0.0
    dom_frac=(max(freq.values())/nd) if (freq and nd) else 0.0
    fits=[e[0] for e in evals]; dls=[e[1] for e in evals]
    return (comp_frac, dom_frac, mg.size(),
            sum(fits)/len(fits), max(fits), min(fits),
            sum(dls)/len(dls), max(dls))

def run():
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    rng=random.Random(SEED); mg=MetaGenome(); pop=init_population(rng)
    gens=[]; comp_fracs=[]; dom_fracs=[]; mg_sizes=[]
    mean_fit_l=[]; max_fit_l=[]; min_fit_l=[]; mean_dlen_l=[]; max_dlen_l=[]
    pr_l=[]; db_l=[]; cap_l=[]; del_l=[]; rescue_l=[]
    singularity_gen=None; backflow_gen=None
    events={"captures":0,"opens":0,"baseline_bounds":0,"open_bounds":0,"deletions":0,"rescues":0}
    t0=time.time()
    for gen in range(GENERATIONS+1):
        evals=evaluate_population(pop,mg)
        cf,df,mgsz,mf,xf,nf,mdl,xdl=compute_light_stats(pop,mg,evals)
        if singularity_gen is None and df>=SINGULARITY_THRESHOLD: singularity_gen=gen
        gens.append(gen); comp_fracs.append(cf); dom_fracs.append(df); mg_sizes.append(mgsz)
        mean_fit_l.append(mf); max_fit_l.append(xf); min_fit_l.append(nf)
        mean_dlen_l.append(mdl); max_dlen_l.append(xdl)
        pr_l.append(len(mg.pr)); db_l.append(len(mg.db))
        cap_l.append(events["captures"]); del_l.append(events["deletions"]); rescue_l.append(events["rescues"])
        if gen%PROGRESS_EVERY==0:
            print(f"  gen {gen:4d} mg={mgsz:5d} comp={cf:.3f} dom={df:.3f} "
                  f"fit={mf:.1f}/{xf:.1f} dlen={mdl:.0f}/{xdl:.0f} "
                  f"pr={len(mg.pr):3d} db={len(mg.db):3d} cap={events['captures']:3d} "
                  f"del={events['deletions']:3d} resc={events['rescues']:3d} t={time.time()-t0:.1f}s", flush=True)
        events={"captures":0,"opens":0,"baseline_bounds":0,"open_bounds":0,"deletions":0,"rescues":0}
        if gen<GENERATIONS:
            # Service set S(t): top-level composition tokens referenced by the
            # WHOLE population during this generation's fitness evaluation. The
            # decode pass over every organism emits the participation signal in a
            # single comprehensive pass, including the effect of recent mutations.
            service = set()
            for e in evals:
                service |= e[2]
            pop, ne, survivor_top = make_next_generation_l6(pop, evals, rng)
            for org in pop[ne:]:
                mutate_org(org, mg, rng, events)
            # GADS Chain 3/4: participation signal from the evaluated population
            #  - refresh PR position for in-PR comps
            #  - rescue from DB for in-DB comps
            for cid in service:
                if cid in mg.pr:
                    mg.pr_refresh(cid)
                elif cid in mg.db:
                    if mg.db_rescue(cid):
                        events["rescues"] += 1
            # then age + delete the unrescued
            deleted = mg.db_tick()
            events["deletions"] += len(deleted)
            if mg.backflow_failure:
                backflow_gen=gen+1
                print(f"\n  *** BACKFLOW at gen {backflow_gen} ***",flush=True); break
    print(f"\n  singularity_gen={singularity_gen} backflow_gen={backflow_gen} "
          f"final_mg={mg_sizes[-1]} final_dom={dom_fracs[-1]:.3f} "
          f"final_meanfit={mean_fit_l[-1]:.1f} final_meandlen={mean_dlen_l[-1]:.0f}", flush=True)

    fig,ax=plt.subplots(2,2,figsize=(15,9))
    ax[0,0].plot(gens,mean_fit_l,label="mean",color="tab:blue")
    ax[0,0].plot(gens,max_fit_l,label="max",color="tab:green",alpha=0.7)
    ax[0,0].plot(gens,min_fit_l,label="min",color="tab:red",alpha=0.4)
    ax[0,0].axhline(FITNESS_THRESHOLD,color="gray",ls="--",lw=0.8)
    ax[0,0].set_title("Fitness"); ax[0,0].set_xlabel("gen"); ax[0,0].legend(fontsize=7)
    ax[0,1].plot(gens,comp_fracs,label="comp frac",color="tab:orange")
    ax[0,1].plot(gens,dom_fracs,label="dominant frac",color="tab:red")
    ax[0,1].axhline(SINGULARITY_THRESHOLD,color="darkred",ls="--",lw=0.8,label="singularity")
    ax[0,1].set_ylim(0,1); ax[0,1].set_title("Token fractions"); ax[0,1].set_xlabel("gen"); ax[0,1].legend(fontsize=7)
    ax[1,0].plot(gens,mg_sizes,color="tab:purple",label="MG size")
    ax[1,0].plot(gens,mean_dlen_l,color="tab:cyan",label="mean decoded len")
    ax[1,0].axhline(FITNESS_THRESHOLD,color="gray",ls="--",lw=0.8)
    ax[1,0].set_title("MG size & decoded len"); ax[1,0].set_xlabel("gen"); ax[1,0].legend(fontsize=7)
    ax[1,1].plot(gens,cap_l,label="captures",color="tab:green",alpha=0.7)
    ax[1,1].plot(gens,del_l,label="deletions",color="tab:red",alpha=0.7)
    ax[1,1].plot(gens,rescue_l,label="rescues",color="tab:blue",alpha=0.7)
    ax[1,1].set_title("Metabolic activity (cap/del/rescue)"); ax[1,1].set_xlabel("gen"); ax[1,1].legend(fontsize=7)
    fig.suptitle(f"theory_sim6 GADS  pop={POPULATION_SIZE} gens={GENERATIONS} seed={SEED} xover=OFF")
    fig.tight_layout(); out=os.path.join(OUTPUT_FOLDER,"diagnostic.png"); fig.savefig(out,dpi=130); plt.close(fig)
    print(f"  wrote {out}",flush=True)

if __name__=="__main__":
    run()
