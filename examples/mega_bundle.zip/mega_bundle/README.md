# MEGA — simulation, movie generator, and pipeline player

This bundle contains everything to (1) just watch a recorded run, (2) regenerate
the movie from new parameters, and (3) run the underlying scientific simulation.

## TL;DR — just watch it
Open **`mega_movie.html`** in any web browser. Press play. No install, no server,
no internet — all the run data is baked into that one file.

It plays a real run of MEGA phase by phase: selection → breeding → per-edit
mutation → capture → participation → deletion/inlining. Click any composition
(M#) to trace it across every panel; click an organism row to "watch" it. Scrub
to the later generations (~gen 60+) to see compositions get captured, reused,
nested, then aged out and dissolved (inlined).

---

## What MEGA is (one paragraph)
A representation-evolving genetic algorithm. Genomes are sequences over a tiny
alphabet under a length-target fitness. Crossover is OFF. The novelty is a shared
**metagenome**: subsequences that get delimited can be **captured** into reusable
composition tokens (M#), which other organisms then reuse — this is the only
cross-lineage recombination channel. Captured compositions are managed by a
metabolic pipeline: a **participation register** (active, in-use compositions), a
**deletion basket** (unused, at-risk compositions), **rescue** (a basket
composition used again by a survivor returns to active), and **inlining** (a
truly-unused composition is deleted and its definition spliced back into anything
that referenced it — information pushed back up the hierarchy). The point is a
sustained bounded non-equilibrium: construction (capture) balanced by dissipation
(inlining), never collapsing to a fixed point, never bloating without bound.

---

## The files
| file | what it is |
|------|-----------|
| `mega_movie.html` | **The player + a recorded run, self-contained.** Open and play. |
| `movie_log.json` | The recorded run data (the beats the player reads). |
| `movie_player_template.html` | The player with a `__DATA__` placeholder — the source used to build `mega_movie.html`. Not runnable on its own. |
| `dash_gen.py` | Instrumented generator: runs the MEGA mechanism and emits the beat-by-beat `movie_log.json` for the player. |
| `theory_sim6_gads.py` | The canonical scientific simulation (no visualization overhead). Run this for real experiments. |

You need Python 3 (3.9+). `theory_sim6_gads.py` uses matplotlib for its
diagnostic plot; `dash_gen.py` uses only the standard library. Install matplotlib
with `pip install matplotlib` if you want the science plot.

---

## 1. Regenerate the movie from new parameters
Two steps: generate the beat log, then inline it into the player template.

```bash
# (a) generate a new run's beats. These are the parameters used for the bundled run:
POP=20 GENS=90 SEED=22 FT=70 PR=10 BGP=0.40 CAP=0.14 LOG=movie_log.json MOVIE=1 python3 dash_gen.py

# (b) inline the beats into the player to make a standalone HTML:
python3 - <<'PY'
import json
d=json.load(open('movie_log.json'))
for b in d['beats']:
    b['pop']=[o[:64] for o in b['pop']]          # cap display length per organism
    b.pop('fit',None)
    if 'dlen' in b: b['meanlen']=round(sum(b['dlen'])/len(b['dlen']),1); del b['dlen']
html=open('movie_player_template.html').read().replace(
    '__DATA__','window.RUN_DATA='+json.dumps(d,separators=(',',':'))+';')
open('mega_movie.html','w').write(html)
print('built mega_movie.html')
PY
```

### Parameters you can change (env vars for `dash_gen.py`)
| var | meaning | bundled value |
|-----|---------|---------------|
| `POP` | population size (every organism is shown, so keep ≲24 for legibility) | 20 |
| `GENS` | generations to run | 90 |
| `SEED` | RNG seed (changes the whole run; seed 22 nests early) | 22 |
| `FT` | fitness/length target | 70 |
| `PR` | participation-register capacity (smaller = faster turnover; ~10 shows LRU ordering clearly) | 10 |
| `BGP` | base-gene probability — base:composition selection split (0.40 = 40:60 favoring compositions) | 0.40 |
| `CAP` | capture probability | 0.14 |
| `MOVIE` | 1 = emit beats for the player; 0 = generation-level frames | 1 |

Notes:
- More generations and per-edit detail = more beats = bigger file. The bundled run
  is ~2400 beats / ~13 MB inlined (compresses to ~0.3 MB in a zip).
- Hierarchy depth and inlining are emergent *late* phenomena — compositions must
  accumulate and fall out of use before they dissolve, which takes roughly 50
  generations of warm-up. This is the real dynamics, not a tuning artifact. Lower
  `PR` brings the dissolve phase earlier.

---

## 2. Run the canonical science simulation
`theory_sim6_gads.py` is the scientific artifact (no per-beat logging overhead).
It prints per-generation diagnostics (metagenome size, dominance fraction, mean
fitness, mean decoded length, captures/deletions/rescues) and writes a plot.

```bash
POP=500 GENS=5000 SEED=1 FT=300 python3 theory_sim6_gads.py
```
Env vars: `POP`, `GENS`, `SEED`, `FT`. (PR capacity is fixed at 50 = pi14 here.)
Watch for: metagenome size building then holding bounded, dominance fraction
staying low (no single composition taking over), fitness pinned near the target,
turnover continuing — i.e. a sustained bounded non-equilibrium rather than
collapse (singularity) or unbounded bloat.

---

## A correction worth knowing about
An earlier version of the mutation code swapped delimiters (boundaries) on nearly
every pass (~99.8%), because the delimiter branch had no no-op residual. The
correct behavior: the only general mutation legal on a boundary is swap, firing at
the normal A1 mutation rate, else no-op. Both `theory_sim6_gads.py` and
`dash_gen.py` here have the fix. Any results produced before it had hyperactive
boundaries and should be re-run.

---

## Reading the player (quick legend)
- Tokens: `(` `)` boundaries, `a`/`b` base genes, `M#` compositions. Shaded boxes
  are bounded regions — the only place capture can fire.
- Event borders: capture = yellow, reuse = blue, rescue = green, delete = red,
  inline = orange, boundary swap = purple, boundary = cyan, open = lime.
- Click an `M` = sticky interior-fill trace of that composition everywhere.
- Click an organism row = "watch" it (stays highlighted as you step).
- **MG (metagenome)** is the compositional DAG panel — the hierarchy of
  compositions and their reference edges. That graph *is* the metagenome.
- **Metabolic pipeline** is the panel of composition rows plus the PR / MCO /
  service-set / inline machinery that regulates MG (Chains 3–7: PR, DB, inlining,
  EA, MCO).
- **PR (participation register)** = usage-recency ordering (LRU). Most recently
  used at top, displacement boundary (next to fall out) at bottom. Capacity π14.
- **MCO (meta-gene creation order)** = creation order with exponential decay
  weight; newest composition has the highest sampling weight. This is a *different*
  ordering from PR — PR is by use, MCO is by creation.
- **Service set** = the compositions referenced by surviving organisms this
  generation (cleared and rebuilt each generation). A composition in the service
  set but displaced to the DB (marked ⤴) is the rescue case.
- Each composition row shows its status: `PR` (active in the register) or
  `DB N` (displaced to the deletion basket at age N). The orange inline box
  appears when a referenced composition dissolves, showing its parents rewriting
  in place.
